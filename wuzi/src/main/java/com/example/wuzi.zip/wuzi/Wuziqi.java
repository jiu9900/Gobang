package com.example.wuzi;

import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.application.Application;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import static java.lang.Math.min;

public class Wuziqi extends Application {
    public static int WinCount=5;
    public static int Bsize=15;
    public static double Csize=40;//boardsize & cellsize
    public static Board board;
    public void start(Stage stage) throws Exception {
        Pane root=new Pane();
        board=new Board(Bsize,Csize);
        root.getChildren().add(board);
        Scene scene=new Scene(root,Bsize*Csize,Bsize*Csize);
        root.prefHeightProperty().bind(scene.heightProperty());
        root.prefWidthProperty().bind(scene.widthProperty());
        scene.widthProperty().addListener((obs,oldval,newval)->{
            Csize=min(scene.getWidth(),scene.getHeight())/Bsize;
            board=new Board(Bsize,Csize);
            root.getChildren().clear();
            root.getChildren().add(board);
            board.setLayoutX((scene.getWidth()-Bsize*Csize)/2);
            board.setLayoutY((scene.getHeight()-Bsize*Csize)/2);
        });
        scene.heightProperty().addListener((obs,oldval,newval)->{
            Csize=min(scene.getWidth(),scene.getHeight())/Bsize;
            board=new Board(Bsize,Csize);
            root.getChildren().clear();
            root.getChildren().add(board);
            board.setLayoutX((scene.getWidth()-Bsize*Csize)/2);
            board.setLayoutY((scene.getHeight()-Bsize*Csize)/2);
        });
        stage.setTitle("五子棋");
        stage.setScene(scene);
        stage.show();
    }
}
