package com.example.wuzi;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Circle;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;

public class Point extends StackPane{
    private int x,y;
    private boolean vis;
    Circle stone;
    Point(int x,int y){
        this.x=x;this.y=y;
        setPrefSize(Wuziqi.Csize,Wuziqi.Csize);
        setLayoutX((x-1.5)*Wuziqi.Csize);
        setLayoutY((y-1.5)*Wuziqi.Csize);
        stone=new Circle(Wuziqi.Csize/2.0);
        stone.setVisible(false);
        getChildren().add(stone);

        setOnMouseClicked(this::Click);
    }
    void Click(MouseEvent event){
        if(vis) return;
        vis=true;
        if(Board.col){
            stone.setFill(Color.WHITE);
            Board.a[x][y]=1;
        }else{
            stone.setFill(Color.BLACK);
            Board.a[x][y]=0;
        }
        stone.setVisible(true);
        if(Wuziqi.board.check(x,y)) return;
        Board.col=!Board.col;
    }
}
