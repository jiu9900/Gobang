package com.example.wuzi;
import javafx.application.Platform;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.control.Alert;
import java.util.Optional;
import javafx.scene.control.ButtonType;

public class Board extends Pane{
    private int Bsize;
    private double Csize;
    public static boolean col=false;
    public static int[][] a;
    private final Rectangle background;
    Board(int X,double Y){
        Bsize=X;
        Csize=Y;
        background=new Rectangle(X*Y,X*Y);
        background.setFill(Color.web("#FFE4C4"));
        getChildren().add(background);
        drawLines(X,Y);
        BuildPoints();
    }
    void drawLines(int X,double Y){
        for(int i=1;i<=X;++i) for(int j=1;j<=X;++j){
            getChildren().add(new Line(0,(i-1)*Y,X*Y,(i-1)*Y));
            getChildren().add(new Line((j-1)*Y,X*Y,(j-1)*Y,0));
        }
    }
    void BuildPoints(){
        a=new int[Bsize+1][Bsize+1];
        for(int i=1;i<=Bsize;++i) for(int j=1;j<=Bsize;++j){
            a[i][j]=-1;
            getChildren().add(new Point(i,j));
        }
    }
    void reset(){
        col=false;
        getChildren().clear();
        getChildren().add(background);
        drawLines(Bsize,Csize);
        BuildPoints();
    }
    void end(){
        Alert qwq=new Alert(Alert.AlertType.CONFIRMATION);
        qwq.setTitle("Game Over!");
        if(col) qwq.setHeaderText("白棋获胜！");
        else qwq.setHeaderText("黑棋获胜！");
        qwq.setContentText("再来一盘？");
        Optional<ButtonType> result=qwq.showAndWait();
        if(result.get()!=ButtonType.OK) Platform.exit();
        reset();
    }
    boolean check(int x,int y){
        int c1,c2;

        c1=c2=0;
        for(int xx=x,yy=y;xx<=Bsize&&yy<=Bsize;xx++,yy++){
            if(a[xx][yy]!=a[x][y]) break;
            c1++;
        }
        for(int xx=x,yy=y;xx>0&&yy>0;xx--,yy--){
            if(a[xx][yy]!=a[x][y]) break;
            c2++;
        }
        if(c1+c2>Wuziqi.WinCount){
            end();
            return true;
        }

        c1=c2=0;
        for(int xx=x,yy=y;xx<=Bsize&&yy>0;xx++,yy--){
            if(a[xx][yy]!=a[x][y]) break;
            c1++;
        }
        for(int xx=x,yy=y;xx>0&&yy<=Bsize;xx--,yy++){
            if(a[xx][yy]!=a[x][y]) break;
            c2++;
        }
        if(c1+c2>Wuziqi.WinCount){
            end();
            return true;
        }

        c1=c2=0;
        for(int i=x;i>0;i--){
            if(a[i][y]!=a[x][y]) break;
            c1++;
        }
        for(int i=x;i<=Bsize;i++){
            if(a[i][y]!=a[x][y]) break;
            c2++;
        }
        if(c1+c2>Wuziqi.WinCount){
            end();
            return true;
        }

        c1=c2=0;
        for(int i=y;i>0;i--){
            if(a[x][i]!=a[x][y]) break;
            c1++;
        }
        for(int i=y;i<=Bsize;i++){
            if(a[x][i]!=a[x][y]) break;
            c2++;
        }
        if(c1+c2>Wuziqi.WinCount){
            end();
            return true;
        }
        return false;
    }
}
